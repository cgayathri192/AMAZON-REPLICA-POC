import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { SellerUpdateProductComponent } from './seller-update-product.component';
import { ActivatedRoute, convertToParamMap } from '@angular/router';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormsModule } from '@angular/forms';
import { of} from 'rxjs';
import { ProductService } from '../services/product.service';

describe('SellerUpdateProductComponent', () => {
  let component: SellerUpdateProductComponent;
  let fixture: ComponentFixture<SellerUpdateProductComponent>;
  let productService: ProductService;

  const mockProductData = {
    id: 1,
    name: 'Test Product',
    price: 10,
    category: 'Test Category',
    color: 'Test Color',
    description: 'Test Description',
    image: 'test.jpg',
    quantity: 5,
    productId: 123
  };

  const activatedRouteStub = {
    snapshot: {
      paramMap: convertToParamMap({ id: 'test-id' }) 
    }
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SellerUpdateProductComponent],
      providers: [
        { provide: ActivatedRoute, useValue: activatedRouteStub }
      ],
      imports: [HttpClientTestingModule, FormsModule]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SellerUpdateProductComponent);
    component = fixture.componentInstance;
    productService = TestBed.inject(ProductService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize product data on ngOnInit', () => {
    spyOn(productService, 'getproduct').and.returnValue(of(mockProductData));
    component.ngOnInit();
    expect(component.ProductData).toEqual(mockProductData);
  });

  it('should update product and show success message', fakeAsync(() => {
    const updatedProductData = { ...mockProductData, name: 'Updated Product' };
    spyOn(productService, 'updateProduct').and.returnValue(of(updatedProductData));
    component.ProductData = mockProductData;
    component.submit(updatedProductData);
    expect(productService.updateProduct).toHaveBeenCalledWith(updatedProductData);
    expect(component.productMessage).toBe('Product has updated');
    tick(3000);
    expect(component.productMessage).toBeUndefined();
  }));
  
});
