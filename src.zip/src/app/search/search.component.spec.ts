import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { SearchComponent } from './search.component';
import { ProductService } from '../services/product.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { product } from '../data-type';
import { of } from 'rxjs';

describe('SearchComponent', () => {
  let component: SearchComponent;
  let fixture: ComponentFixture<SearchComponent>;
  let productService: jasmine.SpyObj<ProductService>;

  beforeEach(async(() => {
    const productServiceSpy = jasmine.createSpyObj('productService', ['searchProduct']);
    TestBed.configureTestingModule({
      declarations: [ SearchComponent ],
      providers: [
        {
          provide: ActivatedRoute,
          useValue:{
            snapshot: {
              paramMap: {
                get: () => 'mockedquery'
              }
            }
          }
        } ,
        {provide: ProductService , useValue: productServiceSpy}
      ],
      imports:[HttpClientTestingModule]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchComponent);
    component = fixture.componentInstance;
    productService = TestBed.inject(ProductService) as jasmine.SpyObj<ProductService>
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set searchResult when searchProduct is called', () => {
    const mockProducts: product[] = [
      {
        name: 'Mock Product',
        price: 50,
        category: 'Mock Category',
        color: 'Mock Color',
        description: 'Mock Description',
        image: 'mock-image-url.jpg',
        id: 1,
        quantity: 1,
        productId: 101
      }
    ];
    productService.searchProduct.and.returnValue(of(mockProducts));

    component.ngOnInit();

    expect(productService.searchProduct).toHaveBeenCalled(); 
    expect(component.searchResult).toEqual(mockProducts); 
  });
  
});
