import { Component, OnInit } from '@angular/core';
import { ProductService } from '../services/product.service';
import { cart, product } from '../data-type';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
popularProducts:product[] = [];
trendyProducts:product[] = [];
  constructor(private product:ProductService) { }

  ngOnInit(): void {
    const popularProducts$ = this.product.popularProducts();
    if (popularProducts$) {
         popularProducts$.subscribe((data) => {
        this.popularProducts = data || [];
      });
    }
    const trendyProducts$ = this.product.trendyProducts();
    if (trendyProducts$) {
      trendyProducts$.subscribe((data) => {
        this.trendyProducts = data || [];
      });
    }
  
  }


}
