import { TestBed, ComponentFixture, tick, fakeAsync } from '@angular/core/testing';
import { HomeComponent } from './home.component';
import { ProductService } from '../services/product.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { of } from 'rxjs';
import { product } from '../data-type';

describe('HomeComponent', () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;
  let productService: jasmine.SpyObj<ProductService>;

  beforeEach(async () => {
    const productServiceSpy = jasmine.createSpyObj('ProductService',['popularProducts' , 'trendyProducts']);
    await TestBed.configureTestingModule({
      declarations: [ HomeComponent ],
      imports: [ HttpClientTestingModule ],
      providers: [ 
        {provide: ProductService, useValue: productServiceSpy}
       ]
    }).compileComponents();

    productService = TestBed.inject(ProductService) as jasmine.SpyObj<ProductService>;

  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
  it('should fetch popular products on initialization', fakeAsync(() => {
    const mockProducts: product[] = 
    [
      {
        name: 'Example Product',
        price: 50,
        category: 'Example Category',
        color: 'Example Color',
        description: 'Example Description',
        image: 'example-image-url.jpg',
        id: 1,
        quantity: 1,
        productId: 101
      }
    ]
    const popularProducts$ = of(mockProducts);
    productService.popularProducts.and.returnValue(popularProducts$);
    
    spyOn(popularProducts$,'subscribe').and.callThrough();

    fixture.detectChanges();
    tick();

    expect(productService.popularProducts).toHaveBeenCalled();
    expect(popularProducts$.subscribe).toHaveBeenCalled();
    expect(component.popularProducts).toEqual(mockProducts);
  }));


  it('should fetch trendy products on initialization', fakeAsync(() => {
    const mockProducts: product[] =
      [
        {
          name: 'Trendy Product',
          price: 100,
          category: 'Trendy Category',
          color: 'Trendy Color',
          description: 'Trendy Description',
          image: 'trendy-image-url.jpg',
          id: 2,
          quantity: 2,
          productId: 102
        }
      ];

    const trendyProducts$ = of(mockProducts);
    productService.trendyProducts.and.returnValue(trendyProducts$);

    
    spyOn(trendyProducts$, 'subscribe').and.callThrough();

    fixture.detectChanges();
    tick();

    
    expect(productService.trendyProducts).toHaveBeenCalled();
    expect(trendyProducts$.subscribe).toHaveBeenCalled(); // Ensure subscribe is called
    expect(component.trendyProducts).toEqual(mockProducts);
  }));

});
