import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MyOrdersComponent } from './my-orders.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { of } from 'rxjs';
import { ProductService } from '../services/product.service';
describe('MyOrdersComponent', () => {
  let component: MyOrdersComponent;
  let fixture: ComponentFixture<MyOrdersComponent>;
  let productService: jasmine.SpyObj<ProductService>;


  beforeEach(async(() => {
    const productServiceSpy = jasmine.createSpyObj('ProductService', ['orderList', 'cancelOrder']);
    TestBed.configureTestingModule({
      declarations: [ MyOrdersComponent ],
      imports:[HttpClientTestingModule],
      providers:[
        {
          provide: ProductService,
          useValue: productServiceSpy
        }
      ]
    })
    .compileComponents();

    productService = TestBed.inject(ProductService) as jasmine.SpyObj<ProductService>;
    productService.orderList.and.returnValue(of([]));
    productService.cancelOrder.and.returnValue(of(true));
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyOrdersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
  it('should call cancelOrder and getOrderList when canceling an order', () => {
    const orderId = 1;
    const mockOrderData = [{ id: 1, email: 'test@example.com', address: '123 Test St', contact: '1234567890', totalprice: 50, userId: 1 }];

    productService.orderList.and.returnValue(of(mockOrderData));

    productService.cancelOrder.and.returnValue(of(true));

    component.cancelOrder(orderId);

    expect(productService.cancelOrder).toHaveBeenCalledWith(orderId);

    expect(productService.orderList).toHaveBeenCalled();
  });
  
});
