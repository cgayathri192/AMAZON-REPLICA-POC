import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { UserAuthComponent } from './user-auth.component';
import { UserService } from '../services/user.service';
import { FormsModule } from '@angular/forms';
import {of} from 'rxjs'

describe('UserAuthComponent', () => {
  let component: UserAuthComponent;
  let fixture: ComponentFixture<UserAuthComponent>;

  const userServiceStub = {
    userAuthReload: () => {}, 
    userSignUp: (data: any) => of(true), 
    userLogin: (data: any) => of(true), 
    inValidUserAuth: of(false) 
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserAuthComponent ],
      imports:[HttpClientTestingModule , FormsModule],
      providers: [{provide: UserService, useValue: userServiceStub}]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserAuthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});



