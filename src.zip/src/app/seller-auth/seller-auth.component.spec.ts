import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormsModule } from '@angular/forms';
import { SellerAuthComponent } from './seller-auth.component';
import { SellerService } from '../services/seller.service';
import { of } from 'rxjs';
import { SignUp } from '../data-type';

describe('SellerAuthComponent', () => {
  let component: SellerAuthComponent;
  let fixture: ComponentFixture<SellerAuthComponent>;
  let sellerService: SellerService;

  const sellerServiceStub = {
    reloadSeller: () => {},
    userSignUp: (data: SignUp) => of(true),
    userLogin: (data: SignUp) => of(true),
    isLoginError: of(false)
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SellerAuthComponent],
      providers: [
        { provide: SellerService, useValue: sellerServiceStub }
      ],
      imports: [HttpClientTestingModule, FormsModule]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SellerAuthComponent);
    component = fixture.componentInstance;
    sellerService = TestBed.inject(SellerService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call userSignUp method of SellerService on signUp', () => {
    spyOn(sellerService, 'userSignUp').and.callFake(()=>{
      return of(true);
    });
    const signUpData: SignUp = { name: 'Test', password: 'password', email: 'test@test.com' };
    component.signUp(signUpData);
    expect(sellerService.userSignUp).toHaveBeenCalledWith(signUpData);
  });

  it('should call userLogin method of SellerService on login', () => {
    spyOn(sellerService, 'userLogin').and.callFake(() => {
      return of(true);
    });
        const loginData: SignUp = { name: 'Test', password: 'password', email: 'test@test.com' };
    component.login(loginData);
    expect(sellerService.userLogin).toHaveBeenCalledWith(loginData);
  });

  it('should set authError message if userLogin method of SellerService returns error', () => {
    const errorMessage = 'Error occurred';
    spyOn(sellerService, 'userLogin').and.callFake(()=>{
      return of(false);
    })
    spyOn(console, 'error');
    const loginData: SignUp = { name: 'Test', password: 'password', email: 'test@test.com' };
    component.login(loginData);
    expect(component.authError).toEqual('Email or password is not correct');
  });
});

