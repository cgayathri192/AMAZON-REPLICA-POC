import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { HeaderComponent } from './header.component';
import { ProductService } from '../services/product.service';
import { RouterTestingModule } from '@angular/router/testing';
import { of } from 'rxjs';
import { Router } from '@angular/router';
import { product } from '../data-type';
import { EventEmitter } from '@angular/core';

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;
  let productService: jasmine.SpyObj<ProductService>;
  let router: Router;

  beforeEach(async(() => {
    productService = jasmine.createSpyObj('ProductService', ['getCartList', 'searchProduct']);
    TestBed.configureTestingModule({
      declarations: [ HeaderComponent ],
      providers:[
        { provide: ProductService, useValue: productService }
      ],
      imports:[RouterTestingModule]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    router = TestBed.inject(Router);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should subscribe to router events and update properties', fakeAsync(() => {
    const mockUserData = { id: 1, name: 'Test User' };
    localStorage.setItem('user', JSON.stringify(mockUserData));
    const routerSpy = spyOn(router.events, 'subscribe').and.callThrough();
    fixture.ngZone?.run(() => {
      router.navigateByUrl('/user-profile');
    });
    tick();
    expect(component.menuType).toBe('user');
    expect(component.userName).toBe(mockUserData.name);
    expect(productService.getCartList).toHaveBeenCalledWith(mockUserData.id);
  }));

  it('should clear local storage and navigate to default route on logout', () => {
    const logoutSpy = spyOn(component, 'userLogout').and.callThrough();
    const routerSpy = spyOn(router, 'navigate').and.callThrough();
    component.userLogout();
    expect(localStorage.getItem('user')).toBeNull();
    expect(routerSpy).toHaveBeenCalledWith(['/user-auth']);
  });

  it('should search for products and update search result', () => {
    const query = 'test';
    const mockResult = [
      { id: 1, name: 'Product 1', price: 10, category: 'Category 1', color: 'Red', description: 'Description 1', image: 'image1.jpg' },
      { id: 2, name: 'Product 2', price: 20, category: 'Category 2', color: 'Blue', description: 'Description 2', image: 'image2.jpg' }
    ];
    productService.searchProduct.and.returnValue(of(mockResult as product[]));
    const event = new KeyboardEvent('keyup');
    Object.defineProperty(event, 'target', { value: { value: query } });  
    component.searchProduct(event);
    expect(productService.searchProduct).toHaveBeenCalledWith(query);
    expect(component.searchResult).toEqual(mockResult as product[]);
  });
  
  it('should update cart items count based on ProductService', fakeAsync(() => {
    const mockCartItems = [
      { id: 1, name: 'Product 1', price: 10, category: 'Category 1', color: 'Red', description: 'Description 1', image: 'image1.jpg', quantity: 1, productId: 1001 },
      { id: 2, name: 'Product 2', price: 20, category: 'Category 2', color: 'Blue', description: 'Description 2', image: 'image2.jpg', quantity: 1, productId: 1002 }
    ];
    
    // Initialize productService.cartData as an EventEmitter
    productService.cartData = new EventEmitter<any>();

    // Spy on productService.cartData subscribe method
    spyOn(productService.cartData, 'subscribe').and.callThrough();
    
    // Trigger the ngOnInit lifecycle hook of the component
    component.ngOnInit();

    // Emit mockCartItems after the component has subscribed to productService.cartData
    productService.cartData.emit(mockCartItems);
    
    // Update the fixture and wait for asynchronous tasks to complete
    fixture.detectChanges();
    tick();
    
    // Assert that the cartItems property has been updated correctly
    expect(component.cartItems).toBe(mockCartItems.length);

    // Assert that productService.cartData.subscribe has been called
    expect(productService.cartData.subscribe).toHaveBeenCalled();
  }));
  
});
