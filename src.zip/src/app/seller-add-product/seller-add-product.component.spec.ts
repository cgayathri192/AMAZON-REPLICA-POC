import { ComponentFixture, TestBed, tick, fakeAsync } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { of } from 'rxjs';
import { SellerAddProductComponent } from './seller-add-product.component';
import { ProductService } from '../services/product.service';
import { product } from '../data-type';

describe('SellerAddProductComponent', () => {
  let component: SellerAddProductComponent;
  let fixture: ComponentFixture<SellerAddProductComponent>;
  let productService: ProductService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SellerAddProductComponent],
      imports: [FormsModule, HttpClientTestingModule],
      providers: [ProductService]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SellerAddProductComponent);
    component = fixture.componentInstance;
    productService = TestBed.inject(ProductService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set addProductMessage when product is added successfully', fakeAsync(() => {
    const testData: product = {
      name: 'Test Product',
      price: 10,
      category: 'Test Category',
      color: 'Red',
      description: 'Test Description',
      image: 'test.jpg',
      id: 1,
      quantity: 10,
      productId: 100
    };
    spyOn(productService, 'addProduct').and.returnValue(of(true));
    
    component.submit(testData);
    tick();
    
    expect(component.addProductMessage).toEqual('Product is added successfully');
    // Ensure addProductMessage is reset after 3 seconds
    tick(3001);
    expect(component.addProductMessage).toBeUndefined();
  }));
});
