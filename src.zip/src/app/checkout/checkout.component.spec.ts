// import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
// import { HttpClientTestingModule } from '@angular/common/http/testing';
// import { RouterTestingModule } from '@angular/router/testing';
// import { FormsModule } from '@angular/forms';
// import { CheckoutComponent } from './checkout.component';
// import { of } from 'rxjs';
// import { ProductService } from '../services/product.service';

// describe('CheckoutComponent', () => {
//   let component: CheckoutComponent;
//   let fixture: ComponentFixture<CheckoutComponent>;
//   let productService: jasmine.SpyObj<ProductService>;
//   let router:any;

//   beforeEach(async(() => {
//     productService = jasmine.createSpyObj('ProductService', ['currentCart', 'orderNow', 'deleteCartItems']);
//     TestBed.configureTestingModule({
//       declarations: [CheckoutComponent],
//       imports:[HttpClientTestingModule , RouterTestingModule, FormsModule],
//       providers:[
//         { provide: ProductService, useValue: productService }
//       ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(CheckoutComponent);
//     component = fixture.componentInstance;
//     router = TestBed.inject(RouterTestingModule);
//     productService.currentCart.and.returnValue(of([]));
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });

// });




import { TestBed, ComponentFixture, tick, fakeAsync } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { of } from 'rxjs';
import { CheckoutComponent } from './checkout.component';
import { ProductService } from '../services/product.service';

describe('CheckoutComponent', () => {
  let component: CheckoutComponent;
  let fixture: ComponentFixture<CheckoutComponent>;
  let productService: jasmine.SpyObj<ProductService>;
  let router: any;

  beforeEach(async () => {
    productService = jasmine.createSpyObj('ProductService', ['currentCart', 'orderNow', 'deleteCartItems']);
    await TestBed.configureTestingModule({
      declarations: [CheckoutComponent],
      imports: [FormsModule, RouterTestingModule, HttpClientTestingModule],
      providers: [
        { provide: ProductService, useValue: productService }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckoutComponent);
    component = fixture.componentInstance;
    router = TestBed.inject(RouterTestingModule);
    productService.currentCart.and.returnValue(of([]));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should calculate total price correctly', fakeAsync(() => {
    const cartData = [
      { name: 'Product 1', price: 10, quantity: 2 },
      { name: 'Product 2', price: 20, quantity: 1 }
    ];
    productService.currentCart.and.returnValue(of(cartData as any));
    fixture.detectChanges();
    tick();
    expect(component.totalPrice).toEqual(100); 
  }));

  it('should place order successfully', fakeAsync(() => {
    const orderData = { email: 'test@example.com', address: '123 Street', contact: '1234567890' };
    const cartData = [
      { id: 1, name: 'Product 1', price: 10, quantity: 2 },
      { id: 2, name: 'Product 2', price: 20, quantity: 1 }
    ];
    productService.currentCart.and.returnValue(of(cartData as any));
    fixture.detectChanges();
    tick();

    component.totalPrice = 132;
  
    component.orderNow(orderData);
    tick(); 
  
    expect(productService.orderNow).toHaveBeenCalledWith({
      email: 'test@example.com',
      address: '123 Street',
      contact: '1234567890',
      totalprice: 132,
      userId: undefined,
      id: undefined
    });
    expect(productService.deleteCartItems).toHaveBeenCalledTimes(2);
    expect(component.orderMsg).toEqual('Your order has been placed');
  }));
  

});



