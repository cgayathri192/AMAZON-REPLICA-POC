import { TestBed, fakeAsync, inject, tick } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { SellerService } from './seller.service';
import { Router } from '@angular/router';

describe('SellerService', () => {
  let service: SellerService;
  let httpMock: HttpTestingController;
  let router: Router

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [SellerService]
    });
    service = TestBed.inject(SellerService);
    httpMock = TestBed.inject(HttpTestingController);
    router = TestBed.inject(Router);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should sign up a user', fakeAsync(() => {
    const navigateSpy = spyOn(router, 'navigate').and.returnValue(Promise.resolve(true)); 

    const signupData = { name: 'Test Seller', email: 'test@example.com', password: 'password' };
    service.userSignUp(signupData);

    const req = httpMock.expectOne('http://localhost:3000/seller');
    expect(req.request.method).toEqual('POST');
    req.flush(signupData);

    expect(localStorage.getItem('seller')).toEqual(JSON.stringify(signupData));
    tick();

    expect(navigateSpy).toHaveBeenCalledWith(['seller-home']);
  }));

  it('should reload seller', fakeAsync(() => {
    const navigateSpy = spyOn(router, 'navigate').and.returnValue(Promise.resolve(true)); 

    localStorage.setItem('seller', JSON.stringify({ name: 'Test Seller', email: 'test@example.com' }));
    service.reloadSeller();

    tick();

    expect(service.isSellerLoggedIn.getValue()).toBe(true);
    expect(navigateSpy).toHaveBeenCalledWith(['seller-home']);
  }));

  it('should emit login error', () => {
    const loginData = { email: 'test@example.com', password: 'wrongpassword' };

    spyOn(service.isLoginError, 'emit');

    service.userLogin(loginData);

    const req = httpMock.expectOne(`http://localhost:3000/seller?email=${loginData.email}&password=${loginData.password}`);
    expect(req.request.method).toEqual('GET');

    req.flush([]);

    expect(service.isLoginError.emit).toHaveBeenCalledWith(true);
  });
  
  it('should navigate to seller-home upon successful login', fakeAsync(() => {
    const navigateSpy = spyOn(router, 'navigate').and.stub(); 
  
    const loginData = { email: 'test@example.com', password: 'test@123' };
    service.userLogin(loginData);
  
    const req = httpMock.expectOne(`http://localhost:3000/seller?email=${loginData.email}&password=${loginData.password}`);
    expect(req.request.method).toEqual('GET');
  
    const mockResponseBody = { name: 'Test Seller', email: 'test@example.com' };
    req.flush(mockResponseBody);
  
    tick();
  
    expect(navigateSpy).toHaveBeenCalledWith(['seller-home']);
}));


  
  
});

