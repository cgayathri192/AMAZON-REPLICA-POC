import { TestBed, fakeAsync, tick } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { UserService } from './user.service';
import { Router } from '@angular/router';

describe('UserService', () => {
  let service: UserService;
  let httpMock: HttpTestingController;
  let router: Router;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientModule, HttpClientTestingModule],
      providers:[UserService]
    });
    service = TestBed.inject(UserService);
    httpMock = TestBed.inject(HttpTestingController);
    router = TestBed.inject(Router);
  });

  afterEach(() => {
    httpMock.verify();
    localStorage.clear();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should sign up user', fakeAsync(() => {
    const mockUser = { name: 'Test User', email: 'test@example.com', password: 'password' };
    service.userSignUp(mockUser);
    const req = httpMock.expectOne('http://localhost:3000/users');
    expect(req.request.method).toBe('POST');
    req.flush(mockUser);
    tick();
    expect(localStorage.getItem('user')).toBeTruthy();
  }));

  it('should login user successfully', fakeAsync(() => {
    const mockLoginData = { email: 'test@example.com', password: 'password' };
    const mockUserResponse = [{ name: 'Test User', email: 'test@example.com', password: 'password' }];
    service.userLogin(mockLoginData);
    const req = httpMock.expectOne(`http://localhost:3000/users?email=${mockLoginData.email}&password=${mockLoginData.password}`);
    expect(req.request.method).toBe('GET');
    req.flush(mockUserResponse);
    tick();
    expect(localStorage.getItem('user')).toBeTruthy();
  }));

  it('should fail login for invalid credentials', fakeAsync(() => {
    const mockLoginData = { email: 'invalid@example.com', password: 'invalid' };
    spyOn(service.inValidUserAuth, 'emit');
    service.userLogin(mockLoginData);
    const req = httpMock.expectOne(`http://localhost:3000/users?email=${mockLoginData.email}&password=${mockLoginData.password}`);
    expect(req.request.method).toBe('GET');
    req.flush([]);  
    tick();
    expect(localStorage.getItem('user')).toBeFalsy();
    expect(service.inValidUserAuth.emit).toHaveBeenCalledWith(true);
  }));
  
  it('should navigate to home page if user is authenticated', fakeAsync(() => {
    spyOn(router, 'navigate').and.stub();
    localStorage.setItem('user', JSON.stringify({ name: 'Test User', email: 'test@example.com', password: 'password' }));
    service.userAuthReload();
    tick();
    expect(router.navigate).toHaveBeenCalledWith(['/']);
  }));

  it('should not navigate if user is not authenticated', fakeAsync(() => {
    spyOn(router, 'navigate').and.stub();
    service.userAuthReload();
    tick();
    expect(router.navigate).not.toHaveBeenCalled();
  }));
});
