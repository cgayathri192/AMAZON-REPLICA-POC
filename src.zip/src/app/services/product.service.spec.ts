import { TestBed, fakeAsync, tick } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ProductService } from './product.service';
import {cart, order, product} from '../data-type';

describe('ProductService', () => {
  let service: ProductService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [ProductService]
    });
    service = TestBed.inject(ProductService);
    httpMock = TestBed.inject(HttpTestingController);
  });
  afterEach(()=>{
    httpMock.verify();
  })

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('should add  a product' , () => {
    const mockProduct: product = {
      name: 'Test Product',
      price: 10,
      category: 'Test Category',
      color: 'Test Color',
      description: 'Test Description',
      image: 'Test Image',
      id: 1,
      quantity: 1,
      productId: 1
    };
      service.addProduct(mockProduct).subscribe(response =>{
        expect(response).toBeTruthy();
        expect(response).toEqual(mockProduct);
      });
       
      const request = httpMock.expectOne('http://localhost:3000/products');
      expect(request.request.method).toBe('POST');
      request.flush(mockProduct);
  })
  it('should retrieve list of products', () => {
    const mockProducts: product[] = [
      {
        name: 'Product 1',
        price: 10,
        category: 'Category 1',
        color: 'Color 1',
        description: 'Description 1',
        image: 'Image 1',
        id: 1,
        quantity: 1,
        productId: 1
      },
      {
        name: 'Product 1',
        price: 10,
        category: 'Category 1',
        color: 'Color 1',
        description: 'Description 1',
        image: 'Image 1',
        id: 1,
        quantity: 1,
        productId: 1
      }

    ];
    service.productList().subscribe(products => {
      // expect(products.length).toBe(2);
      expect(products).toEqual(mockProducts);
    });
  
    const request = httpMock.expectOne('http://localhost:3000/products');
    expect(request.request.method).toBe('GET');
    request.flush(mockProducts); // Flush the mockProducts array as the response
  });
  

  it('should delete a product', () => {
    const productId = 1;

    service.deleteProduct(productId).subscribe(response => {
      expect(response).toBeTruthy();
      expect(response).toEqual(`Product with ID ${productId} deleted successfully`);
    });

    const request = httpMock.expectOne(`http://localhost:3000/products/${productId}`);
    expect(request.request.method).toBe('DELETE');
    request.flush(`Product with ID ${productId} deleted successfully`);
  });
  it('should update a product', () => {
    const mockProduct: product = {
      name: 'Updated Product',
      price: 15,
      category: 'Updated Category',
      color: 'Updated Color',
      description: 'Updated Description',
      image: 'Updated Image',
      id: 1,
      quantity: 1,
      productId: 1
    };

    service.updateProduct(mockProduct).subscribe(response => {
      expect(response).toBeTruthy();
      expect(response).toEqual(mockProduct);
    });

    const request = httpMock.expectOne(`http://localhost:3000/products/${mockProduct.id}`);
    expect(request.request.method).toBe('PUT');
    request.flush(mockProduct);
  });
  it('should fetch popular products', () => {
    const mockPopularProducts: product[] = [
      {
        name: 'Popular Product 1',
        price: 50,
        category: 'Popular Category 1',
        color: 'Popular Color 1',
        description: 'Popular Description 1',
        image: 'Popular Image 1',
        id: 1,
        quantity: 10,
        productId: 101
      },
      {
        name: 'Popular Product 2',
        price: 75,
        category: 'Popular Category 2',
        color: 'Popular Color 2',
        description: 'Popular Description 2',
        image: 'Popular Image 2',
        id: 2,
        quantity: 15,
        productId: 102
      }
    ];

    service.popularProducts().subscribe(products => {
      expect(products.length).toBe(2);
      expect(products).toEqual(mockPopularProducts);
    });

    const request = httpMock.expectOne('http://localhost:3000/products?_limit=10');
    expect(request.request.method).toBe('GET');
    request.flush(mockPopularProducts);
  });

  it('should fetch trendy products', () => {
    const mockTrendyProducts: product[] = [
      {
        name: 'Trendy Product 1',
        price: 60,
        category: 'Trendy Category 1',
        color: 'Trendy Color 1',
        description: 'Trendy Description 1',
        image: 'Trendy Image 1',
        id: 3,
        quantity: 5,
        productId: 103
      },
      {
        name: 'Trendy Product 2',
        price: 80,
        category: 'Trendy Category 2',
        color: 'Trendy Color 2',
        description: 'Trendy Description 2',
        image: 'Trendy Image 2',
        id: 4,
        quantity: 7,
        productId: 104
      }
    ];

    service.trendyProducts().subscribe(products => {
      expect(products.length).toBe(2);
      expect(products).toEqual(mockTrendyProducts);
    });

    const request = httpMock.expectOne('http://localhost:3000/products?_limit=15');
    expect(request.request.method).toBe('GET');
    request.flush(mockTrendyProducts);
  });
  
  it('should fetch products based on search query', () => {
    const query = 'test';
    const mockSearchProducts: product[] = [
      {
        name: 'Test Product 1',
        price: 30,
        category: 'Test Category 1',
        color: 'Test Color 1',
        description: 'Test Description 1',
        image: 'Test Image 1',
        id: 5,
        quantity: 3,
        productId: 105
      },
      {
        name: 'Test Product 2',
        price: 40,
        category: 'Test Category 2',
        color: 'Test Color 2',
        description: 'Test Description 2',
        image: 'Test Image 2',
        id: 6,
        quantity: 4,
        productId: 106
      }
    ];

    service.searchProduct(query).subscribe(products => {
      expect(products.length).toBe(2);
      expect(products).toEqual(mockSearchProducts);
    });

    const request = httpMock.expectOne(`http://localhost:3000/products?q=${query}`);
    expect(request.request.method).toBe('GET');
    request.flush(mockSearchProducts);
  });
  
  it('should add product to local cart', fakeAsync(() => {
    const mockProduct: product = {
      name: 'Test Product',
      price: 10,
      category: 'Test Category',
      color: 'Test Color',
      description: 'Test Description',
      image: 'Test Image',
      id: 1,
      quantity: 1,
      productId: 1
    };
        localStorage.clear();
        service.localAddToCart(mockProduct);
        const localCartData = JSON.parse(localStorage.getItem('localCart'));
        expect(localCartData.length).toBe(1);
        let emittedCartData: product[];
    const subscription = service.cartData.subscribe(data => {
      emittedCartData = data;
    });
        subscription.unsubscribe();
        setTimeout(() => {
    });
    tick();
  }));
  

  it('should emit updated cart data after adding product', () => {
    const mockProduct: product = {
      name: 'Test Product',
      price: 10,
      category: 'Test Category',
      color: 'Test Color',
      description: 'Test Description',
      image: 'Test Image',
      id: 1,
      quantity: 1,
      productId: 1
    };
  
    let emittedCartData: product[] = [];
    const subscription = service.cartData.subscribe(data => {
      emittedCartData = data;
    });
    service.localAddToCart(mockProduct);
    subscription.unsubscribe(); 
    setTimeout(() => {
      // expect(emittedCartData.length).toBe(1);
      expect(emittedCartData[0]).toEqual(mockProduct);
    });
  
  });
  

  it('should add product to the cart', () => {
    const mockCartData: cart = {
      productId: 1,
      quantity: 2,
      userId: 1,
      name: 'Test Product',
      price: 10,
      category: 'Test Category',
      color: 'Test Color',
      description: '',
      image: '',
      id: 0
    }
  
    const mockResponseData: product[] = [
      {
        name: 'Test Product',
        price: 10,
        category: 'Test Category',
        color: 'Test Color',
        description: 'Test Description',
        image: 'Test Image',
        id: 1,
        quantity: 1,
        productId: 1
      }
    ];
  
    service.addToCart(mockCartData).subscribe(response => {
      expect(response).toBeTruthy();
      expect(response).toEqual(mockResponseData);
    });
  
    const request = httpMock.expectOne('http://localhost:3000/cart');
    expect(request.request.method).toBe('POST');
    expect(request.request.body).toEqual(mockCartData);
    request.flush(mockResponseData);
  });
  
  it('should remove product from the cart', () => {
    const mockCartId = 1;
  
    service.removeToCart(mockCartId).subscribe(response => {
      expect(response).toBeTruthy();
      expect(response).toEqual(`Product with ID ${mockCartId} removed from the cart successfully`);
    });
  
    const request = httpMock.expectOne(`http://localhost:3000/cart/${mockCartId}`);
    expect(request.request.method).toBe('DELETE');
    request.flush(`Product with ID ${mockCartId} removed from the cart successfully`);
  });
  
  it('should remove product from local cart', () => {
    const mockProductId = 1;
    const mockCartData: product[] = [
      {
        name: 'Product 1',
        price: 10,
        category: 'Category 1',
        color: 'Color 1',
        description: 'Description 1',
        image: 'Image 1',
        id: 1,
        quantity: 1,
        productId: 1
      },
      {
        name: 'Product 2',
        price: 20,
        category: 'Category 2',
        color: 'Color 2',
        description: 'Description 2',
        image: 'Image 2',
        id: 2,
        quantity: 2,
        productId: 2
      }
    ];
    const updatedCartData: product[] = [
      {
        name: 'Product 2',
        price: 20,
        category: 'Category 2',
        color: 'Color 2',
        description: 'Description 2',
        image: 'Image 2',
        id: 2,
        quantity: 2,
        productId: 2
      }
    ];
      localStorage.setItem('localCart', JSON.stringify(mockCartData));
      service.removeItemFromCart(mockProductId);
      const updatedLocalCartData = JSON.parse(localStorage.getItem('localCart'));
      expect(updatedLocalCartData.length).toBe(1);
    expect(updatedLocalCartData).toEqual(updatedCartData);
      service.cartData.subscribe(data => {
      expect(data.length).toBe(1);
      expect(data).toEqual(updatedCartData);
    });
  });
  it('should emit cart data when calling getCartList', () => {
    const userId = 1;
    const mockProducts: product[] = [
      {
        name: 'Product 1',
        price: 10,
        category: 'Category 1',
        color: 'Color 1',
        description: 'Description 1',
        image: 'Image 1',
        id: 1,
        quantity: 1,
        productId: 1
      },
      {
        name: 'Product 2',
        price: 20,
        category: 'Category 2',
        color: 'Color 2',
        description: 'Description 2',
        image: 'Image 2',
        id: 2,
        quantity: 2,
        productId: 2
      }
    ];

    service.getCartList(userId);

    const req = httpMock.expectOne(`http://localhost:3000/cart?userId=${userId}`);
    expect(req.request.method).toBe('GET');

    req.flush(mockProducts);

    service.cartData.subscribe(data => {
      expect(data.length).toBe(2);
      expect(data).toEqual(mockProducts);
    });
  });
  

  it('should retrieve current cart based on user ID', () => {
    const userData = { id: 1 };
    spyOn(localStorage, 'getItem').and.returnValue(JSON.stringify(userData));

    const mockCartData: cart[] = [
      {
        productId: 1,
        quantity: 2,
        userId: 1,
        name: 'Test Product',
        price: 10,
        category: 'Test Category',
        color: 'Test Color',
        description: '',
        image: '',
        id: 0
      }
    ];

    service.currentCart().subscribe(cart => {
      expect(cart.length).toBe(1);
      expect(cart).toEqual(mockCartData);
    });

    const req = httpMock.expectOne(`http://localhost:3000/cart?userId=${userData.id}`);
    expect(req.request.method).toBe('GET');

    req.flush(mockCartData);
  });

  it('should place an order', () => {
    const mockOrderData:order = { 
      email:'test@example.com',
      address:'xyz',
      contact:'6320111111111111',
      totalprice:100,
      userId:1,
      id:2
     };
  
    service.orderNow(mockOrderData).subscribe(response => {
      expect(response).toBeTruthy();
    
    });
  
    const req = httpMock.expectOne('http://localhost:3000/orders');
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual(mockOrderData);
    req.flush({  });
  });

  it('should retrieve order list based on user ID', () => {
    const userData = { id: 1 };
    spyOn(localStorage, 'getItem').and.returnValue(JSON.stringify(userData));
  
    const mockOrderList: order[] = [
      {
        email: 'test@example.com',
        address: 'xyz',
        contact: '6320111111111111',
        totalprice: 100,
        userId: 1,
        id: 2
      }
    ];
  
    service.orderList().subscribe(orders => {
      expect(orders.length).toBe(1);
      expect(orders).toEqual(mockOrderList);
    });
  
    const req = httpMock.expectOne(`http://localhost:3000/orders?userId=${userData.id}`);
    expect(req.request.method).toBe('GET');
  
    req.flush(mockOrderList);
  });
  


  it('should delete cart items', (done: DoneFn) => {
    const cartId = 1;

    const subscription = service.deleteCartItems(cartId);
    expect(subscription.unsubscribe).toBeTruthy(); 
    const req = httpMock.expectOne(`http://localhost:3000/cart/${cartId}`);
    expect(req.request.method).toBe('DELETE');
    req.flush(null);

    done();
  });

  it('should cancel order', () => {
    const orderId = 1;

    service.cancelOrder(orderId).subscribe(response => {
      expect(response).toBeTruthy(); 
    });
    const req = httpMock.expectOne(`http://localhost:3000/orders/${orderId}`);
    expect(req.request.method).toBe('DELETE');
    req.flush({}); 
  });
  
  

});
