import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CartPageComponent } from './cart-page.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ProductService } from '../services/product.service';
import { of } from 'rxjs';
import { Router } from '@angular/router';

describe('CartPageComponent', () => {
  let component: CartPageComponent;
  let fixture: ComponentFixture<CartPageComponent>;
  let productService: ProductService;
  let router: Router

  const mockCartData = [
    {
      name: 'Test Product',
      price: 10,
      category: 'Test Category',
      color: 'Test Color',
      description: 'Test Description',
      image: 'Test Image',
      id: 1,
      quantity: 1,
      userId: 1,
      productId: 1
    }
  ];

  const productServiceStub = {
    currentCart: jasmine.createSpy('currentCart').and.returnValue(of(mockCartData)),
    removeToCart: jasmine.createSpy('removeToCart').and.returnValue(of(null))
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CartPageComponent],
      imports:[HttpClientTestingModule , RouterTestingModule],
      providers: [
        { provide: ProductService, useValue: productServiceStub },
        { provide: Router, useClass: class { navigate = jasmine.createSpy('navigate'); } }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CartPageComponent);
    component = fixture.componentInstance;
    productService = TestBed.inject(ProductService);
    router = TestBed.inject(Router);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });  

  it('should remove item from cart', () => {
    const cartId = 1;
    component.removeToCart(cartId);
    expect(productService.removeToCart).toHaveBeenCalledWith(cartId);
    expect(component.cartData).toEqual(mockCartData);
  });
  
  it('should navigate to checkout page', () => {
    component.checkout();
    expect(router.navigate).toHaveBeenCalledWith(['/checkout']); 
  });

});
