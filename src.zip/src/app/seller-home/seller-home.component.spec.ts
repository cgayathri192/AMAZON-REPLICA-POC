import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { SellerHomeComponent } from './seller-home.component';
import { ProductService } from '../services/product.service';
import { of } from 'rxjs';

describe('SellerHomeComponent', () => {
  let component: SellerHomeComponent;
  let fixture: ComponentFixture<SellerHomeComponent>;
  let productService: jasmine.SpyObj<ProductService>;

  beforeEach(async(() => {
    const productServiceSpy = jasmine.createSpyObj('ProductService', ['productList', 'deleteProduct']);

    TestBed.configureTestingModule({
      declarations: [ SellerHomeComponent ],
      imports:[HttpClientTestingModule],
      providers:[
        {provide:ProductService , useValue:productServiceSpy}
      ]
    })
    .compileComponents();
    productService = TestBed.inject(ProductService) as jasmine.SpyObj<ProductService>;
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SellerHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should call deleteProduct and list when deleting a product', fakeAsync(() => {
    const productId = 1;
    productService.productList.and.returnValue(of([]));
    productService.deleteProduct.and.returnValue(of(true));
  
    component.deleteProduct(productId);
  
    expect(productService.deleteProduct).toHaveBeenCalledWith(productId);
    expect(productService.productList).toHaveBeenCalled();

    tick(3000);
  
    expect(component.productMessage).toBeUndefined();
  }));
});
